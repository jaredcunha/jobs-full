<header id="site-header" class="hdr-main empty" role="banner">
	<div class="wrap">
		<div class="top-bar">
			<p class="logo-main"><a href="<?php echo home_url(); ?>"><img src="/wp-content/themes/ls-careers/dist/prod/images/svg/logo.svg" alt="<?php bloginfo( 'name' ); ?>"></a></p>
			</div>
	</div>

<?php if( ! is_front_page() ) : ?>
</header>
<?php endif;?>

	
		
