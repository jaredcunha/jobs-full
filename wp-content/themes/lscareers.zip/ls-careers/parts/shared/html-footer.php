
	<?php wp_footer(); ?>
	<script src="/wp-content/themes/ls-careers/dist/prod/js/modernizr.js"></script>
	<script src="/wp-content/themes/ls-careers/dist/prod/js/global.js"></script>

	</body>
</html>